package com.example.synergyapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SynergyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
